//
//  TableViewController.swift
//  Actividad10
//
//  Created by user188675 on 10/21/21.
//  Copyright © 2021 user188675. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    
    let names = ["Carlos", "Luis", "Pedro", "Jose"]

    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return names.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"celda")!
        cell.textLabel?.text = names[indexPath.row]
        //Configurar celda el código cell.textLabel?.text = nombres [indexPath.row].
        return cell
    }
}
